package tiendaVideojuegos;

import java.sql.Date;
import java.util.List;

public class Pedido {
	private String IDpedido;
	private String productoSolicitado;
	private int cantidad;
	private String estadoPedido;
	private Date fechaRealizacion;
	private String direccionEnvio;
	private Lpedido lpedido;
	private List<Producto> productos;

	public Pedido() {
		this.lpedido = new Lpedido();
	}

	public Date getFechaRealizacion() {
		return fechaRealizacion;
	}

	public void setFechaRealizacion(Date fechaRealizacion) {
		this.fechaRealizacion = fechaRealizacion;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	public String getIDpedido() {
		return IDpedido;
	}

	public void setIDpedido(String iDpedido) {
		IDpedido = iDpedido;
	}

	public String getProductoSolicitado() {
		return productoSolicitado;
	}

	public void setProductoSolicitado(String productoSolicitado) {
		this.productoSolicitado = productoSolicitado;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public String getEstadoPedido() {
		return estadoPedido;
	}

	public void setEstadoPedido(String estadoPedido) {
		this.estadoPedido = estadoPedido;
	}

	public Date getFechaRealziacion() {
		return fechaRealizacion;
	}

	public void setFechaRealziacion(Date fechaRealziacion) {
		this.fechaRealizacion = fechaRealziacion;
	}

	public String getDireccionEnvio() {
		return direccionEnvio;
	}

	public void setDireccionEnvio(String direccionEnvio) {
		this.direccionEnvio = direccionEnvio;
	}

	public Lpedido getLpedido() {
		return lpedido;
	}

	public void setLpedido(Lpedido lpedido) {
		this.lpedido = lpedido;
	}

}
