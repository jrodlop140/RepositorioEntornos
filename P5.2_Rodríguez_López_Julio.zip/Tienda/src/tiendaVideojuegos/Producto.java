package tiendaVideojuegos;

public class Producto {
	private int videojuegos;
	private int consolas;
	private int accesorios;
	private String descripcion;
	private boolean disponibilidad;
	private Inventario inventario;

	public Producto() {
		this.inventario = new Inventario();
	}

	public int getVideojuegos() {
		return videojuegos;
	}

	public void setVideojuegos(int videojuegos) {
		this.videojuegos = videojuegos;
	}

	public int getConsolas() {
		return consolas;
	}

	public void setConsolas(int consolas) {
		this.consolas = consolas;
	}

	public int getAccesorios() {
		return accesorios;
	}

	public void setAccesorios(int accesorios) {
		this.accesorios = accesorios;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public boolean isDisponibilidad() {
		return disponibilidad;
	}

	public void setDisponibilidad(boolean disponibilidad) {
		this.disponibilidad = disponibilidad;
	}

	public Inventario getInventario() {
		return inventario;
	}

	public void setInventario(Inventario inventario) {
		this.inventario = inventario;
	}

}
