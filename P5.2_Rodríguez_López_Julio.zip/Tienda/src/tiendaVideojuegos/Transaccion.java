package tiendaVideojuegos;

import java.time.LocalDateTime;
import java.util.List;

public class Transaccion {
	private String IDtransacicon;
	private String tipoTransaccion;
	private LocalDateTime fechaHoraTransaccion;
	private List<Producto> productos;

	public Transaccion() {

	}

	public String getIDtransacicon() {
		return IDtransacicon;
	}

	public void setIDtransacicon(String iDtransacicon) {
		IDtransacicon = iDtransacicon;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public LocalDateTime getFechaHoraTransaccion() {
		return fechaHoraTransaccion;
	}

	public void setFechaHoraTransaccion(LocalDateTime fechaHoraTransaccion) {
		this.fechaHoraTransaccion = fechaHoraTransaccion;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

}
