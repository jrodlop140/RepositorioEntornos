package tiendaVideojuegos;

public class Inventario {
	private String inventario;
	private int Stock;
	private int unidadesReservadas;
	private int unidadesVendidas;

	public Inventario() {

	}

	public String getInventario() {
		return inventario;
	}

	public void setInventario(String inventario) {
		this.inventario = inventario;
	}

	public int getStock() {
		return Stock;
	}

	public void setStock(int stock) {
		Stock = stock;
	}

	public int getUnidadesReservadas() {
		return unidadesReservadas;
	}

	public void setUnidadesReservadas(int unidadesReservadas) {
		this.unidadesReservadas = unidadesReservadas;
	}

	public int getUnidadesVendidas() {
		return unidadesVendidas;
	}

	public void setUnidadesVendidas(int unidadesVendidas) {
		this.unidadesVendidas = unidadesVendidas;
	}

}
