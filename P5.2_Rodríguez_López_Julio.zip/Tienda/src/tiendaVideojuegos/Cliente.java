package tiendaVideojuegos;

public class Cliente extends Usuario {
	private String IDcliente;
	private String historialCompra;
	private String preferencia;

	public Cliente() {
		super();
	}

	public String getIDcliente() {
		return IDcliente;
	}

	public void setIDcliente(String iDcliente) {
		IDcliente = iDcliente;
	}

	public String getHistorialCompra() {
		return historialCompra;
	}

	public void setHistorialCompra(String historialCompra) {
		this.historialCompra = historialCompra;
	}

	public String getPreferencia() {
		return preferencia;
	}

	public void setPreferencia(String preferencia) {
		this.preferencia = preferencia;
	}

}
