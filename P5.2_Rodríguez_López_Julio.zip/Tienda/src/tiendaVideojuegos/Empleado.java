package tiendaVideojuegos;

import java.sql.Date;
import java.util.List;

public class Empleado extends Usuario {
	private String IDempleado;
	private String rol;
	private Date horarioLaboral;
	private String historialVenta;
	private String permioAcceso;
	private List<Transaccion> transacciones;

	public List<Transaccion> getTransacciones() {
		return transacciones;
	}

	public void setTransacciones(List<Transaccion> transacciones) {
		this.transacciones = transacciones;
	}

	public Empleado() {
		super();
	}

	public String getIDempleado() {
		return IDempleado;
	}

	public void setIDempleado(String iDempleado) {
		IDempleado = iDempleado;
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

	public Date getHorarioLaboral() {
		return horarioLaboral;
	}

	public void setHorarioLaboral(Date horarioLaboral) {
		this.horarioLaboral = horarioLaboral;
	}

	public String getHistorialVenta() {
		return historialVenta;
	}

	public void setHistorialVenta(String historialVenta) {
		this.historialVenta = historialVenta;
	}

	public String getPermioAcceso() {
		return permioAcceso;
	}

	public void setPermioAcceso(String permioAcceso) {
		this.permioAcceso = permioAcceso;
	}

}
